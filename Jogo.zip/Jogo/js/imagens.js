let imagemDaEstrada;
let imagemDoMascote;
let imagemDoCarro01;
let imagemDoCarro02;
let imagemDoCarro03;


function preload(){
    imagemDaEstrada = loadImage("img/estrada.png");
    imagemDoMascote = loadImage("img/Mordecai.png");
    imagemDoCarro01 = loadImage("img/carro-1.png");
    imagemDoCarro02 = loadImage("img/carro-2.png");
    imagemDoCarro03 = loadImage("img/carro-3.png");

    imagensCarros = 
    [imagemDoCarro01, imagemDoCarro02, imagemDoCarro03, imagemDoCarro01, imagemDoCarro02, imagemDoCarro03]
}
