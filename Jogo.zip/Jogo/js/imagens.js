let imagemDoParque;
let imagemDoMascote;
let imagemDoVilao1;
let imagemDoVilao2;
let imagemDoVilao3;


function preload(){
    imagemDoParque = loadImage("img/Parque.png");
    imagemDoMascote = loadImage("img/Mordecai.png");
    imagemDoVilao1 = loadImage("img/vilao.png");
    imagemDoVilao2 = loadImage("img/vilao2.png");
    imagemDoVilao3 = loadImage("img/vilao3.png");

    imagensVilao = 
    [imagemDoVilao1, imagemDoVilao2, imagemDoVilao3, imagemDoVilao1, imagemDoVilao2, imagemDoVilao3]
}
