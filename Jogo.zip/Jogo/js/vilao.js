
// let xVilao = 700;
// let xVilao2 =700;
// let xVilao3 =700;
let xVilao = [700, 700, 700, 700, 700, 700]
let yVilao = [40, 90, 140, 200, 270, 340]

let comprimentoVilao=60;
let alturaVilao=60;
let velocidadeVilao = [5,6,9.2,8.6,10,9.5,13]

function mostrarVilao(){

    for (let i = 0; i < imagensVilao.length; i++) {
        
        image(imagensVilao[i], xVilao[i], yVilao[i], comprimentoVilao, alturaVilao)
    }

    //  image(imagemDoVilao1, xVilao, 40, comprimentoVilao, alturaVilao);
    //  image(imagemDoVilao2, xVilao2, 100, 60, 40);
    //  image(imagemDoVilao3, xVilao3, 150, 60, 40);
}

function movimentoVilao(){

    for (let i = 0; i < imagensVilao.length; i++) {
        
        xVilao[i] -= velocidadeVilao[i];
        if(xVilao[i] < -50){
            xVilao[i] = 700;
        }
        
    }

}
