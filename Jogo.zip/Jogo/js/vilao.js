
// let xVilao = 700;
// let xVilao2 =700;
// let xVilao3 =700;
let xVilao = [700, 700, 700, 700, 700, 700]
let yVilao = [50, 100, 150, 200, 250, 300]

let comprimentoVilao=50;
let alturaVilao=40;
let velocidadeVilao = [5,3.9,8,6,9,11]

function mostrarVilao(){

    for (let i = 0; i < imagensVilao.length; i++) {
        
        image(imagensVilao[i], xVilao[i], yVilao[i], comprimentoVilao, alturaVilao)
    }

    //  image(imagemDoVilao1, xVilao, 40, comprimentoVilao, alturaVilao);
    //  image(imagemDoVilao2, xVilao2, 100, 60, 40);
    //  image(imagemDoVilao3, xVilao3, 150, 60, 40);
}

function movimentoVilao(){

    for (let i = 0; i < imagensVilao.length; i++) {
        
        xVilao[i] -= velocidadeVilao[i];
        if(xVilao[i] < -50){
            xVilao[i] = 700;
        }
        
    }

}
