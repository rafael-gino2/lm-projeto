
// let xCarros = 700;
// let xCarros2 =700;
// let xCarros3 =700;
let xCarros = [700, 700, 700, 700, 700, 700]
let yCarros = [50, 100, 150, 200, 250, 300]

let comprimentoCarros=40;
let alturaCarros=30;
let velocidadeCarros = [5,3.9,8,6,9,11]

function mostrarCarros(){

    for (let i = 0; i < imagensCarros.length; i++) {
        
        image(imagensCarros[i], xCarros[i], yCarros[i], 40, 30)
    }

    //  image(imagemDoCarro01, xCarros, 40, comprimentoCarros, alturaCarros);
    //  image(imagemDoCarro02, xCarros2, 100, 60, 40);
    //  image(imagemDoCarro03, xCarros3, 150, 60, 40);
}

function movimentoCarro(){

    for (let i = 0; i < imagensCarros.length; i++) {
        
        xCarros[i] -= velocidadeCarros[i];
        if(xCarros[i] < -50){
            xCarros[i] = 700;
        }
        
    }

}
