

// na função setup, definimos as configurações de largura e altura
function setup(){
    createCanvas(800, 500);
}

// na função de desenho definimos o que será exibido
function draw(){
    background(imagemDoParque);
    mostrarVilao();
    movimentoVilao();
    movimentoMascote();
    mostrarMascote();
    incluirPontos();
    verificaColisao();
}

