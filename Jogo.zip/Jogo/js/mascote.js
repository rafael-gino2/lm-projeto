let yMascote =330;
let xMascote = 70;
let meusPontos = 0;
let diametro = 5;

function mostrarMascote(){
    image(imagemDoMascote, xMascote, yMascote, 40, 40)
}

function incluirPontos(){
    text(meusPontos, 20, 25)
    fill (color(225, 0, 0))
    textSize(21)

    if (yMascote < 0) {
        yMascote = 360
        meusPontos ++
    }
}

function colisao() {
    collideRectCircle(xCarros, yCarros, comprimentoCarros, alturaCarros, xMascote, yMascote);
    if (colidiu) {
        xMascote *= -1;
    }
}

function movimentoMascote(){
    if(keyIsDown(UP_ARROW)){
        yMascote -=5;
    }

    if(keyIsDown(DOWN_ARROW)){
        yMascote +=5;
    }

    if(keyIsDown(LEFT_ARROW)){
        xMascote -=5;
    }

    if(keyIsDown(RIGHT_ARROW)){
        xMascote +=5;
    }
}
    