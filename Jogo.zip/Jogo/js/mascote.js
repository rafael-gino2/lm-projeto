//posição mascote//
let yMascote =330;
let xMascote = 70;
let meusPontos = 0;

let colisao = false;


function verificaColisao(){

    for (let i = 0; i < imagensVilao.length; i++) {
        colisao = collideRectCircle(xVilao[i], yVilao[i], comprimentoVilao, alturaVilao, xMascote, yMascote, 15 );

        if (colisao) {
            yMascote = 360

            if (meusPontos > 0) {
                meusPontos -=1
            }
        }
    }

    print('Colisão acontecendo', colisao);
}

function mostrarMascote(){
    image(imagemDoMascote, xMascote, yMascote, 45, 45)
}

function incluirPontos(){
    text(meusPontos, 20, 25)
    fill (color(225, 0, 0))
    textSize(21)

    if (yMascote < 0) {
        yMascote = 360
        meusPontos ++
    }
}


function movimentoMascote(){
    if(keyIsDown(UP_ARROW)){
        yMascote -=5;
    }

    if(keyIsDown(DOWN_ARROW)){
        yMascote +=5;
    }

    if(keyIsDown(LEFT_ARROW)){
        xMascote -=5;
    }0

    if(keyIsDown(RIGHT_ARROW)){
        xMascote +=5;
    }
}
    